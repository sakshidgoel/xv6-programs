#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{

	printf(1,"WOW It really works\n");
	printf(1,"It is always fun to work w xv6\n");
	exit();

}
